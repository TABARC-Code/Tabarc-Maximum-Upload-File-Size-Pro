<?php
/**
 * Uninstall cleanup for Tabarc Maximum Upload File Size Pro.
 *
 * Earlier builds left their cups in the sink. This one clears its own options,
 * transients, and upload log table when WordPress removes it properly.
 *
 * @package Tabarc MUFS
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

$options = array(
    'wmufs_settings',
    'wmufs_user_storage_limits',
    'wmufs_file_type_rules',
    'wmufs_internal_version',
    'wmufs_log_table_version',
    'wmufs_maximum_execution_time',
    'wmufs_memory_limit',
    'wmufs_notice_disable_time',
);

foreach ($options as $option) {
    delete_option($option);
    delete_site_option($option);
}

$transients = array(
    'wmufs_settings_updated',
    'tabarc_promo_data',
    'tabarc_blog_posts',
);

foreach ($transients as $transient) {
    delete_transient($transient);
    delete_site_transient($transient);
}

$wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->prefix . 'wmufs_upload_logs');

// Per-attachment size cache written by the media columns.
$wpdb->delete($wpdb->postmeta, array('meta_key' => '_wmufs_file_size'), array('%s'));

// Remove leftover partial uploads and the temp folder (default location only).
$wmufs_temp_dir = WP_CONTENT_DIR . '/wmufs-temp';
if (is_dir($wmufs_temp_dir)) {
    $wmufs_temp_files = array_merge(
        (array) glob($wmufs_temp_dir . '/*.part'),
        array($wmufs_temp_dir . '/index.php', $wmufs_temp_dir . '/.htaccess')
    );

    foreach ($wmufs_temp_files as $wmufs_temp_file) {
        if (is_file($wmufs_temp_file)) {
            @unlink($wmufs_temp_file);
        }
    }

    @rmdir($wmufs_temp_dir); // Only succeeds if the folder is now empty.
}
