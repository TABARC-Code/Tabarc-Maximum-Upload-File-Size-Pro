=== Tabarc Maximum Upload File Size Pro ===
Contributors: tabarc
Tags: media, uploads, upload limit, file size, upload logs, user quotas, file type restrictions
Requires at least: 4.0
Requires PHP: 7.0
Tested up to: 6.9
Stable tag: 4.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Manage WordPress upload limits, user storage quotas, file type rules, upload logs, media columns, statistics, and CSV reports from one admin screen.

== Description ==

Tabarc Maximum Upload File Size Pro is a complete GitHub build of the media handling plugin. It keeps the original job intact: raise and control upload limits without editing php.ini, .htaccess, or server config by hand.

Version 4.0.0 adds the admin features that were previously scattered across copy, partial screens, and wishful thinking. The result is a practical WordPress media console: limits, logs, quotas, type rules, reports, and a little more accountability when somebody uploads a 900 MB file named final-final-really-final.zip.

= Top Features at a Glance =

* Upload Logs & Tracking: Records user, file name, size, extension, MIME type, source, and timestamp for each upload.
* Attachment Usage Detection: Checks obvious usage across featured images, post/page content, and WooCommerce-style product galleries.
* Set User Storage Disk Limit: Adds individual total storage quotas for users.
* File Type Restriction: Restricts allowed extensions by role or individual user.
* Role-Based Restrictions: Sets upload limits for Administrator, Editor, Author, and custom roles.
* Media Manager: Adds file size and uploader columns to the media library, plus a compact recent-media view.
* Upload Statistics Dashboard: Shows logged upload totals, storage, top uploaders, and largest files.
* Advanced Reporting: Exports upload logs as CSV.
* Auto Setup & Repair: Creates and repairs the upload log table on activation and version change.
* Better Security: Blocks uploads that break quota or file type rules and records who uploaded what and when.

= What 4.0.0 Changed =

This build removes the old locked-feature posture. There is no locked screen, no licence gate, and no locked Pro tab. The plugin presents itself as a complete Pro version for GitHub use and sharing.

Previous versions did useful work:

* 1.x handled the first obvious need: increasing the maximum upload size.
* 2.x added system status and memory controls.
* 3.x added role-based limits.
* 4.x adds logging, quotas, file type rules, reporting, media columns, and the cleaner Pro dashboard.

= Admin Location =

After activation, go to:

Media > Tabarc MUFS Pro

= Practical Notes =

A WordPress plugin can set WordPress-side limits, execution time, and memory requests. Your server can still enforce a lower ceiling. If the host caps uploads at 64 MB, the host wins. Annoying, but true.

File type restrictions in this plugin narrow what users may upload. They do not expand WordPress MIME support for unsafe file types.

The usage detector is intentionally conservative. It checks common WordPress storage patterns instead of parsing every page-builder payload on every request. That is a future job for a background index, not a punishment for opening the Logs tab.

== Installation ==

1. Upload the `tabarc-maximum-upload-file-size` folder to `/wp-content/plugins/`.
2. Activate `Tabarc Maximum Upload File Size Pro` from the Plugins screen.
3. Go to `Media > Tabarc MUFS Pro`.
4. Set global limits, role limits, user quotas, file type rules, and reporting preferences.

== Frequently Asked Questions ==

= Can this bypass my host upload limit? =

No. It can adjust WordPress and PHP-facing settings where possible, but server-level restrictions still apply.

= Are user storage limits per upload or total storage? =

They are total storage quotas. Role limits handle per-file upload size.

= Do file type rules allow new MIME types? =

No. They restrict users to selected extensions within the normal WordPress upload rules.

= Where are upload logs stored? =

The plugin creates a custom database table named with your WordPress table prefix and `wmufs_upload_logs`.

= Can I export logs? =

Yes. Use the Reports tab to export a CSV.

== Changelog ==

= 4.0.2 =
* Rebuilt the release zip with forward-slash paths for WordPress extractors on Linux.
* Added uninstall.php cleanup for plugin options, transients, and the upload log table.
* Updated internal build ID to cleanroom-pro-2026.07.30.2.

= 4.0.1 =
* Added ABSPATH guards across plugin PHP files.
* Escaped the chunk-upload size-exceeded filename response.
* Added CSV formula-injection protection to upload log exports.
* Changed Clear Upload Logs from a nonce-protected GET link to a nonce-protected POST form.
* Removed dead notice-dismiss wiring from the pre-4.0 admin flow.
* Treated inactive WooCommerce as neutral in System Status.
* Removed dead database-status loading from System Status.
* Updated internal build ID to cleanroom-pro-2026.07.30.1.

= 4.0.0 =
* Cleanroom Pro rebuild for GitHub use.
* Added upload logs with user, file, size, type, source, and timestamp.
* Added attachment usage detection for featured images, post content, and product galleries.
* Added individual user storage quotas.
* Added role and user file type restriction rules.
* Added media library file size and uploader columns.
* Added media manager, statistics, and reporting tabs.
* Added CSV export for upload logs.
* Added activation and version-change repair for the log table.
* Removed locked screens and locked-feature language.
* Updated internal build ID to cleanroom-pro-2026.07.29.1.

= 3.0.4 =
* Declared WordPress compatibility update.

= 3.0.3 =
* Added role-based upload limits.

= 3.0.2 =
* Added PHP 7.0 to 8.3 support notes.
* Added early Pro extension copy.

= 2.0.2 =
* Added memory limit control.
* Rebranded Tabarc MUFS to Tabarc Maximum Upload File Size.

= 2.0.1 =
* Improved system status display.
* Improved admin UI.

= 2.0.0 =
* Major UI improvements.
* Added enhanced system status display.

= 1.0.0 =
* Initial release.