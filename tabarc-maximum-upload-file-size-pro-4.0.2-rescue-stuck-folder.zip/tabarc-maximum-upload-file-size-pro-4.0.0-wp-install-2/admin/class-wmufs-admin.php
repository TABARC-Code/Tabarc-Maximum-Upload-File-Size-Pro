<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin class for Tabarc Maximum Upload File Size Pro.
 *
 * The 4.0.0 rebuild keeps the original upload limit controls and adds the Pro
 * feature tabs directly. No sales detours. People came to manage media, not to
 * admire a toll booth.
 */
class MaxUploader_Admin {

    static function init() {
        if (is_admin()) {
            add_action('admin_enqueue_scripts', array(__CLASS__, 'wmufs_style_and_script'));
            add_action('admin_menu', array(__CLASS__, 'upload_max_file_size_add_pages'));
            add_filter('plugin_action_links_' . WMUFS_PLUGIN_BASENAME, array(__CLASS__, 'plugin_action_links'));
            add_filter('plugin_row_meta', array(__CLASS__, 'plugin_meta_links'), 10, 2);
            add_filter('admin_footer_text', array(__CLASS__, 'admin_footer_text'));
            add_action('admin_init', array(__CLASS__, 'easy_media_form_submission'));
            add_action('admin_head', array(__CLASS__, 'show_admin_notice'));
            add_action('wp_ajax_wmufs_restore_default_settings', array(__CLASS__, 'restore_default_settings_ajax'));
        }

        self::upload_max_increase_upload();
    }

    static function easy_media_form_submission() {
        if (!isset($_POST['easy_media_set_size_limit']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['easy_media_set_size_limit'])), 'easy_media_set_size_action')) {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to change upload settings.', 'tabarc-maximum-upload-file-size'));
        }

        $settings = get_option('wmufs_settings', array());
        if (!is_array($settings)) {
            $settings = array();
        }

        if (isset($_POST['type'])) {
            $settings['limit_type'] = sanitize_text_field(wp_unslash($_POST['type']));
        }

        if (isset($_POST['max_file_size_field'])) {
            $limit = (int) sanitize_text_field(wp_unslash($_POST['max_file_size_field'])) * MB_IN_BYTES;
            if (!isset($settings['max_limits']) || !is_array($settings['max_limits'])) {
                $settings['max_limits'] = array();
            }
            $settings['max_limits']['all'] = $limit;
        }

        if (isset($_POST['role_limits']) && is_array($_POST['role_limits'])) {
            if (!isset($settings['max_limits']) || !is_array($settings['max_limits'])) {
                $settings['max_limits'] = array();
            }

            foreach ($_POST['role_limits'] as $role => $size) {
                $settings['max_limits'][sanitize_key($role)] = (int) sanitize_text_field(wp_unslash($size)) * MB_IN_BYTES;
            }
        }

        if (isset($_POST['max_execution_time_field'])) {
            $settings['max_execution_time'] = (int) sanitize_text_field(wp_unslash($_POST['max_execution_time_field']));
        }

        if (isset($_POST['max_memory_limit_field'])) {
            $settings['max_memory_limit'] = (int) sanitize_text_field(wp_unslash($_POST['max_memory_limit_field'])) * MB_IN_BYTES;
        }

        update_option('wmufs_settings', $settings);
        set_transient('wmufs_settings_updated', __('Settings saved.', 'tabarc-maximum-upload-file-size'), 30);
        wp_safe_redirect(admin_url('admin.php?page=easy_media'));
        exit;
    }

    static function restore_default_settings_ajax() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wmufs_restore_defaults')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'tabarc-maximum-upload-file-size')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'tabarc-maximum-upload-file-size')));
        }

        try {
            delete_option('wmufs_settings');
            delete_option('wmufs_maximum_execution_time');
            delete_option('wmufs_memory_limit');
            delete_option('wmufs_user_storage_limits');
            delete_option('wmufs_file_type_rules');
            delete_transient('wmufs_settings_updated');
            delete_transient('tabarc_promo_data');
            delete_transient('tabarc_blog_posts');

            wp_send_json_success(array('message' => __('Settings have been restored to default values.', 'tabarc-maximum-upload-file-size')));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => __('An error occurred while restoring settings: ', 'tabarc-maximum-upload-file-size') . $e->getMessage()));
        }
    }

    static function show_admin_notice() {
        $message = get_transient('wmufs_settings_updated');
        if ($message) {
            echo '<div class="notice notice-success is-dismissible wmufs-notice"><p>' . esc_html($message) . '</p></div>';
            delete_transient('wmufs_settings_updated');
        }
    }

    static function wmufs_style_and_script() {
        wp_enqueue_style('wmufs-admin-style', WMUFS_PLUGIN_URL . 'assets/css/wmufs.css', array(), WMUFS_PLUGIN_VERSION);
        wp_enqueue_script('jquery');
        wp_enqueue_script('wmufs-admin', WMUFS_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WMUFS_PLUGIN_VERSION, true);

        wp_localize_script('wmufs-admin', 'wmufs_admin_notice_ajax_object', array(
            'wmufs_admin_notice_ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wmufs_notice_status'),
            'plugin_url' => WMUFS_PLUGIN_URL,
            'active_tab' => isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'general',
        ));

        wp_add_inline_script('wmufs-admin', 'var ajaxurl = "' . esc_url(admin_url('admin-ajax.php')) . '";', 'before');
    }

    static function get_plugin_version() {
        return defined('WMUFS_PLUGIN_VERSION') ? WMUFS_PLUGIN_VERSION : '';
    }

    static function is_plugin_page() {
        $current_screen = get_current_screen();
        return $current_screen && $current_screen->id === 'media_page_easy_media';
    }

    public static function plugin_action_links($links) {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=easy_media')),
            esc_html__('Settings', 'tabarc-maximum-upload-file-size')
        );

        array_unshift($links, $settings_link);
        return $links;
    }

    public static function plugin_meta_links($links, $file) {
        return $links;
    }

    static function admin_footer_text($text) {
        if (!self::is_plugin_page()) {
            return $text;
        }

        return '<span id="footer-thankyou">Thank you for using <strong><ins>Tabarc Maximum Upload File Size Pro</ins></strong>.</span>';
    }

    static function upload_max_file_size_add_pages() {
        add_submenu_page(
            'upload.php',
            'Tabarc Maximum Upload File Size Pro',
            'Tabarc MUFS Pro',
            'manage_options',
            'easy_media',
            array(__CLASS__, 'upload_max_file_size_dash')
        );
    }

    static function upload_max_file_size_dash() {
        $active_tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'general';

        $tabs = array(
            'general' => __('General', 'tabarc-maximum-upload-file-size'),
            'system_status' => __('System Status', 'tabarc-maximum-upload-file-size'),
        );

        $tabs = apply_filters('wmufs_admin_tabs', $tabs);
        if (!isset($tabs[$active_tab])) {
            $active_tab = 'general';
        }

        $icons = array(
            'general' => 'dashicons-admin-generic',
            'features' => 'dashicons-editor-ul',
            'upload_logs' => 'dashicons-list-view',
            'user_limits' => 'dashicons-groups',
            'file_types' => 'dashicons-media-code',
            'media_manager' => 'dashicons-category',
            'statistics' => 'dashicons-chart-area',
            'reports' => 'dashicons-media-spreadsheet',
            'system_status' => 'dashicons-chart-bar',
            'license' => 'dashicons-admin-network',
        );
        ?>
        <div class="wmufs-wrap">
            <h2 class="nav-tab-wrapper">
                <?php foreach ($tabs as $tab_key => $tab_label) : ?>
                    <a href="#" data-tab="<?php echo esc_attr($tab_key); ?>" class="nav-tab tabarc-mufs-tab-link <?php echo $active_tab === $tab_key ? 'nav-tab-active' : ''; ?>">
                        <?php if (isset($icons[$tab_key])) : ?>
                            <span class="dashicons <?php echo esc_attr($icons[$tab_key]); ?>"></span>
                        <?php endif; ?>
                        <?php echo wp_kses_post($tab_label); ?>
                    </a>
                <?php endforeach; ?>
            </h2>

            <div id="tabarc-mufs-tab-content">
                <?php include_once WMUFS_PLUGIN_PATH . 'inc/MaxUploaderSystemStatus.php'; ?>

                <?php foreach ($tabs as $tab_key => $tab_label) : ?>
                    <div id="tabarc-mufs-tab-<?php echo esc_attr($tab_key); ?>" class="tabarc-mufs-tab-content" <?php echo $active_tab !== $tab_key ? 'style="display:none;"' : ''; ?>>
                        <?php
                        if ($tab_key === 'general') {
                            include WMUFS_PLUGIN_PATH . 'admin/templates/MaxUploaderForm.php';
                        } elseif ($tab_key === 'system_status') {
                            include WMUFS_PLUGIN_PATH . 'admin/templates/ClassSystemHealth.php';
                        } else {
                            do_action('wmufs_admin_tab_content', $tab_key);
                        }
                        ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        add_action('admin_head', array(__CLASS__, 'wmufs_remove_admin_action'));
    }

    static function wmufs_remove_admin_action() {
        remove_all_actions('user_admin_notices');
        remove_all_actions('admin_notices');
    }

    static function upload_max_increase_upload() {
        $settings = get_option('wmufs_settings', array());

        if (empty($settings) || !is_array($settings)) {
            return;
        }

        $limit_type = isset($settings['limit_type']) ? $settings['limit_type'] : 'global';
        $max_limits = isset($settings['max_limits']) && is_array($settings['max_limits']) ? $settings['max_limits'] : array();

        $max_execution_time = (int) (isset($settings['max_execution_time']) ? $settings['max_execution_time'] : get_option('wmufs_maximum_execution_time'));
        if ($max_execution_time > 0 && function_exists('set_time_limit')) {
            @set_time_limit($max_execution_time);
        }

        $memory_limit = (int) (isset($settings['max_memory_limit']) ? $settings['max_memory_limit'] : get_option('wmufs_memory_limit'));
        if ($memory_limit > 0) {
            @ini_set('memory_limit', round($memory_limit / MB_IN_BYTES) . 'M');
        }

        if ($limit_type === 'global') {
            $global_limit = (int) (isset($max_limits['all']) ? $max_limits['all'] : 0);

            if ($global_limit > 0) {
                add_filter('upload_size_limit', function ($size) use ($global_limit) {
                    return $global_limit;
                });
            }
        } elseif ($limit_type === 'role_based') {
            add_filter('upload_size_limit', function ($size) use ($max_limits) {
                if (is_user_logged_in()) {
                    $user = wp_get_current_user();
                    foreach ($user->roles as $role) {
                        if (isset($max_limits[$role]) && $max_limits[$role] > 0) {
                            return (int) $max_limits[$role];
                        }
                    }
                }

                return $size;
            });
        }
    }
}

add_action('init', array('MaxUploader_Admin', 'init'));