<?php
if (!defined('ABSPATH')) {
    exit;
}

?>
<div class="wmufs_card_mini wmufs_mb_20">
    <div class="support-ticket">
        <h2><?php echo esc_html__('Plugin Notes', 'tabarc-maximum-upload-file-size'); ?></h2>
        <p><?php echo esc_html__('GitHub Pro build. No external payment screen, no licence nag, no mystery module hiding behind a badge.', 'tabarc-maximum-upload-file-size'); ?></p>
        <p><strong><?php echo esc_html__('Version', 'tabarc-maximum-upload-file-size'); ?>:</strong> <?php echo esc_html(WMUFS_PLUGIN_VERSION); ?></p>
        <p><strong><?php echo esc_html__('Internal build', 'tabarc-maximum-upload-file-size'); ?>:</strong> <?php echo esc_html(WMUFS_INTERNAL_VERSION); ?></p>
    </div>
</div>

<div class="wmufs_card_mini wmufs_mb_20">
    <div class="support-ticket wmufs-sidebar-links">
        <h2><?php echo esc_html__('Useful Places', 'tabarc-maximum-upload-file-size'); ?></h2>
        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=easy_media&tab=upload_logs')); ?>">
            <span class="dashicons dashicons-list-view"></span>&nbsp;<?php echo esc_html__('Upload Logs', 'tabarc-maximum-upload-file-size'); ?>
        </a>
        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=easy_media&tab=user_limits')); ?>">
            <span class="dashicons dashicons-groups"></span>&nbsp;<?php echo esc_html__('User Limits', 'tabarc-maximum-upload-file-size'); ?>
        </a>
        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=easy_media&tab=reports')); ?>">
            <span class="dashicons dashicons-media-spreadsheet"></span>&nbsp;<?php echo esc_html__('Reports', 'tabarc-maximum-upload-file-size'); ?>
        </a>
    </div>
</div>

<div class="wmufs_card_mini wmufs_mb_20">
    <div class="support-ticket">
        <h2><?php echo esc_html__('Small Future Idea', 'tabarc-maximum-upload-file-size'); ?></h2>
        <p><?php echo esc_html__('A background storage index would make very large media libraries quicker to audit. Sensible. Not glamorous. Usually the best kind of improvement.', 'tabarc-maximum-upload-file-size'); ?></p>
    </div>
</div>