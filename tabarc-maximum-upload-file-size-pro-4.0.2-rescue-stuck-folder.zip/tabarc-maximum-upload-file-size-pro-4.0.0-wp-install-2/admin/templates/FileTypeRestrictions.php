<?php
if (!defined('ABSPATH')) {
    exit;
}

$rules = WMUFS_Pro_Features::get_file_type_rules();
$roles = WMUFS_Helper::get_available_roles();
$users = WMUFS_Pro_Features::get_upload_users();
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-media-code" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('File Type Rules', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <form method="post">
                    <p><?php esc_html_e('Enter allowed extensions separated by commas. Leave blank to use the normal WordPress allowed MIME list. These rules restrict uploads; they do not magically make unsafe MIME types acceptable.', 'tabarc-maximum-upload-file-size'); ?></p>
                    <h2><?php esc_html_e('Role Rules', 'tabarc-maximum-upload-file-size'); ?></h2>
                    <table class="wp-list-table widefat fixed striped wmufs-data-table">
                        <thead><tr><th><?php esc_html_e('Role', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Allowed Extensions', 'tabarc-maximum-upload-file-size'); ?></th></tr></thead>
                        <tbody>
                        <?php foreach ($roles as $role_key => $role_data) : ?>
                            <tr>
                                <td><?php echo esc_html($role_data['name']); ?><br><small><?php echo esc_html($role_key); ?></small></td>
                                <td><input type="text" class="regular-text" name="role_file_types[<?php echo esc_attr($role_key); ?>]" value="<?php echo esc_attr(isset($rules['roles'][$role_key]) ? implode(', ', $rules['roles'][$role_key]) : ''); ?>" placeholder="jpg, jpeg, png, webp, pdf"></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                    <h2><?php esc_html_e('User Overrides', 'tabarc-maximum-upload-file-size'); ?></h2>
                    <table class="wp-list-table widefat fixed striped wmufs-data-table">
                        <thead><tr><th><?php esc_html_e('User', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Allowed Extensions', 'tabarc-maximum-upload-file-size'); ?></th></tr></thead>
                        <tbody>
                        <?php foreach ($users as $user) : ?>
                            <tr>
                                <td><?php echo esc_html($user->display_name); ?><br><small><?php echo esc_html($user->user_email); ?></small></td>
                                <td><input type="text" class="regular-text" name="user_file_types[<?php echo esc_attr($user->ID); ?>]" value="<?php echo esc_attr(isset($rules['users'][$user->ID]) ? implode(', ', $rules['users'][$user->ID]) : ''); ?>" placeholder="Leave blank for role or WordPress default"></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php wp_nonce_field('wmufs_file_types_action', 'wmufs_file_types_nonce'); ?>
                    <?php submit_button(__('Save File Type Rules', 'tabarc-maximum-upload-file-size')); ?>
                </form>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>