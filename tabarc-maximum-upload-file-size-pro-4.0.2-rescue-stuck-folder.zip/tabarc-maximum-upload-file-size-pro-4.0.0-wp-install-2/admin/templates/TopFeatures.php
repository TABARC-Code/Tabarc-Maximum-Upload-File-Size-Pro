<?php
if (!defined('ABSPATH')) {
    exit;
}

$features = array(
    array('icon' => 'dashicons-list-view', 'title' => __('Upload Logs & Tracking', 'tabarc-maximum-upload-file-size'), 'body' => __('Record who uploaded each file, the file name, size, extension, MIME type, source, and timestamp. Usage detection checks featured images, post content, pages, and product galleries.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-groups', 'title' => __('Set User Storage Disk Limit', 'tabarc-maximum-upload-file-size'), 'body' => __('Give individual users their own total storage quota. It overrides the wider role or global mood of the site, which is useful when one author treats the media library like a garage.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-media-code', 'title' => __('File Type Restriction', 'tabarc-maximum-upload-file-size'), 'body' => __('Allow only selected extensions for roles or individual users. Keep authors on images if that is all they need, and keep ZIP or executable uploads out of ordinary accounts.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-admin-users', 'title' => __('Role-Based Restrictions', 'tabarc-maximum-upload-file-size'), 'body' => __('Set per-file upload limits for Administrator, Editor, Author, and any custom roles your site has collected over the years.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-category', 'title' => __('Media Manager', 'tabarc-maximum-upload-file-size'), 'body' => __('Show file sizes in the WordPress media library and review recent uploads with size, owner, type, and detected usage.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-chart-area', 'title' => __('Upload Statistics Dashboard', 'tabarc-maximum-upload-file-size'), 'body' => __('View total uploads, storage used, top uploaders, recent files, and the heaviest files on the site.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-media-spreadsheet', 'title' => __('Advanced Reporting', 'tabarc-maximum-upload-file-size'), 'body' => __('Export upload logs as CSV for auditing, client reports, or the ritual spreadsheet someone will inevitably request.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-admin-tools', 'title' => __('Auto Setup & Repair', 'tabarc-maximum-upload-file-size'), 'body' => __('The log table is created on activation and repaired after version changes. Not glamorous, but neither is explaining why a dashboard is empty.', 'tabarc-maximum-upload-file-size')),
    array('icon' => 'dashicons-shield-alt', 'title' => __('Better Security', 'tabarc-maximum-upload-file-size'), 'body' => __('The plugin records upload accountability and blocks uploads that break quota or file type rules before they become tomorrow morning problems.', 'tabarc-maximum-upload-file-size')),
);
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-editor-ul" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('Top Features at a Glance', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <div class="wmufs-feature-grid">
                    <?php foreach ($features as $feature) : ?>
                        <div class="wmufs-feature-card">
                            <span class="dashicons <?php echo esc_attr($feature['icon']); ?>"></span>
                            <h2><?php echo esc_html($feature['title']); ?></h2>
                            <p><?php echo esc_html($feature['body']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="wmufs-dev-note">
                    <strong><?php esc_html_e('Version note:', 'tabarc-maximum-upload-file-size'); ?></strong>
                    <?php esc_html_e('4.0.0 turns the old upload-limit utility into a proper media handling console. The earlier versions did useful work, but they made admins jump between intent, settings, and adverts. This build keeps the controls in the room.', 'tabarc-maximum-upload-file-size'); ?>
                </div>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>