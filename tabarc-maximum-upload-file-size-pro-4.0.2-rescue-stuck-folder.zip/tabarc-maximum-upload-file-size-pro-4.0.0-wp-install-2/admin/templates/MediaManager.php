<?php
if (!defined('ABSPATH')) {
    exit;
}

$items = WMUFS_Pro_Features::get_media_items(50);
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-category" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('Media Manager', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <p><?php esc_html_e('WordPress media now gets file size and uploader columns. This page gives the same information in a tighter recent-upload view.', 'tabarc-maximum-upload-file-size'); ?></p>
                <table class="wp-list-table widefat fixed striped wmufs-data-table">
                    <thead><tr><th><?php esc_html_e('File', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Size', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Type', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Uploaded By', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Usage', 'tabarc-maximum-upload-file-size'); ?></th></tr></thead>
                    <tbody>
                    <?php if (empty($items)) : ?>
                        <tr><td colspan="5"><?php esc_html_e('No media items found.', 'tabarc-maximum-upload-file-size'); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ($items as $item) : ?>
                            <?php
                            $user = get_userdata($item->post_author);
                            $usage = WMUFS_Pro_Features::get_attachment_usage($item->ID, 3);
                            ?>
                            <tr>
                                <td><a href="<?php echo esc_url(get_edit_post_link($item->ID)); ?>"><?php echo esc_html(get_the_title($item->ID)); ?></a><br><small><?php echo esc_html(wp_basename(get_attached_file($item->ID))); ?></small></td>
                                <td><?php echo esc_html(WMUFS_Helper::format_bytes(WMUFS_Pro_Features::get_attachment_file_size($item->ID))); ?></td>
                                <td><?php echo esc_html(get_post_mime_type($item->ID)); ?></td>
                                <td><?php echo $user ? esc_html($user->display_name) : esc_html__('Unknown', 'tabarc-maximum-upload-file-size'); ?></td>
                                <td><?php echo esc_html(count($usage)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>