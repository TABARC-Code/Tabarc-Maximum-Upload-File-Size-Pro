<?php
if (!defined('ABSPATH')) {
    exit;
}

// Cross-promotion plugin suggestion removed.
