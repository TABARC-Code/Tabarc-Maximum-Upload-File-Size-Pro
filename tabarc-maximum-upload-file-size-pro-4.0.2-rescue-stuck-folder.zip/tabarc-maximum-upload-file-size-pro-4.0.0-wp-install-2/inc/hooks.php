<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_footer', 'custom_button_inline_after_upload_limit_by_class');

function custom_button_inline_after_upload_limit_by_class() {

    if(!WMUFS_Helper::user_can_manage_options()){
        return;
    }

	$screen = get_current_screen();

	if ($screen && $screen->base === 'media') {
		$custom_link = admin_url('admin.php?page=easy_media');
		?>
		<script type="text/javascript">
            jQuery(document).ready(function($) {
                // Add the settings link near the native upload limit text.
                var uploadNotice = $('p.max-upload-size');

                // Keep it inline so the media screen does not become another notice farm.
                uploadNotice.append(
                    ' <a href="<?php echo esc_url($custom_link); ?>" style="margin-left: 5px;">Change with Tabarc MUFS Pro</a>'
                );



            });
		</script>
		<?php
	}
}

add_action('admin_enqueue_scripts', function($hook) {
    if ($hook === 'upload.php') {
        $custom_link = esc_url( admin_url('admin.php?page=easy_media') );
        wp_add_inline_script('media-views', "
            jQuery(document).ready(function($) {
                // Also run once on first load
                $(window).on('load', function() {
                    const maxText = $('.max-upload-size');
                    if (maxText.length && !maxText.find('a.tabarc-mufs-link').length) {
                        maxText.append(
                            ' <a href=\"{$custom_link}\" class=\"tabarc-mufs-link\" target=\"_blank\" style=\"margin-left:8px;\">Change limit with Tabarc MUFS Pro</a>'
                        );
                    }
                });
            });
        ");
    }
});

