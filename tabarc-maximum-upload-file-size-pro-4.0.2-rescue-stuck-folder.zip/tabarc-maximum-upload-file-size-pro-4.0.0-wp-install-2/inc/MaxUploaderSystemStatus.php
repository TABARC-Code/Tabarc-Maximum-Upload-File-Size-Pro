<?php
if (!defined('ABSPATH')) {
    exit;
}

include_once WMUFS_PLUGIN_PATH . 'inc/MaxUploaderWordPressStatus.php';
$wordpress_status = (new Tabarc_MUFS_WordPressStatus())->get_info();

include_once WMUFS_PLUGIN_PATH . 'inc/MaxUploaderServerStatus.php';
$server_status = (new Tabarc_MUFS_ServerStatus())->get_info();

$system_status = array(
    array(
        'group' => 'WordPress Status',
        'status' => $wordpress_status,
    ),
    array(
        'group' => 'Server Status And PHP Status',
        'status' => $server_status,
    ),
);