<?php
/**
 * Shared helper class for Tabarc Maximum Upload File Size Pro.
 *
 * The old free/pro split left a few checks dotted around the codebase. The GitHub
 * build is a complete Pro build, so these helpers now keep legacy templates calm
 * while newer code calls the feature class directly.
 *
 * @package Tabarc MUFS
 * @since 2.0.3
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WMUFS_Helper {

    /**
     * Check if Pro features are active.
     *
     * @return bool True if premium version is active, false otherwise
     * @since 2.0.3
     */
    public static function is_premium_active() {
        return defined('WMUFS_PRO_VERSION') || class_exists('WMUFS_Pro_Loader') || class_exists('WMUFS_Pro_Features');
    }

    /**
     * Get external URL placeholder.
     *
     * This Pro build is intended for GitHub sharing, so there is no external URL
     * hiding behind the sofa.
     *
     * @return string External URL placeholder
     * @since 2.0.3
     */
    public static function get_upgrade_url() {
        return '';
    }

    /**
     * Get role limits
     * 
     * @return array Array of role limits or empty array if not set
     */
    public static function get_role_limits() {
        $settings = get_option('wmufs_settings', array());
        return is_array($settings) && isset($settings['max_limits']) ? $settings['max_limits'] : array();
    }

    /**
     * Get available WordPress roles
     */
    public static function get_available_roles()
    {
        global $wp_roles;
        return $wp_roles->roles;
    }

    public static function user_can_manage_options() {
        return current_user_can('manage_options');
    }
    /**
     * Return a human-readable file size without surprising empty values.
     *
     * @param int $bytes File size in bytes.
     * @return string
     */
    public static function format_bytes($bytes) {
        $bytes = (int) $bytes;

        if ($bytes <= 0) {
            return '0 B';
        }

        if (function_exists('size_format')) {
            return size_format($bytes, 2);
        }

        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        $power = min((int) floor(log($bytes, 1024)), count($units) - 1);

        return round($bytes / pow(1024, $power), 2) . ' ' . $units[$power];
    }
}
