<?php
if (!defined('ABSPATH')) {
    exit;
}

// Dashboard widget and admin notice promotion removed.
