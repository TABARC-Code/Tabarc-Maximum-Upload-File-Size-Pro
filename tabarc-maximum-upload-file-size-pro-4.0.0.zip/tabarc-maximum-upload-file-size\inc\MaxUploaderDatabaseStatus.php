<?php

class Max_Uploader_Database_Status {

    /**
     * WordPress DB instance
     *
     * @var wpdb
     */
    protected $wpdb;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    /**
     * Get database info in structured format
     *
     * @return array
     */
    public function get_info()
    {
        return array(
            array(
                'title'           => esc_html__( 'Database Name', 'tabarc-maximum-upload-file-size' ),
                'version'         => DB_NAME,
                'status'          => 1,
                'success_message' => esc_html__( '- ok', 'tabarc-maximum-upload-file-size' ),
                'error_message'   => '',
            ),
            array(
                'title'           => esc_html__( 'Database Host', 'tabarc-maximum-upload-file-size' ),
                'version'         => DB_HOST,
                'status'          => 1,
                'success_message' => esc_html__( '- ok', 'tabarc-maximum-upload-file-size' ),
                'error_message'   => '',
            ),
            array(
                'title'           => esc_html__( 'Database User', 'tabarc-maximum-upload-file-size' ),
                'version'         => DB_USER,
                'status'          => 1,
                'success_message' => esc_html__( '- ok', 'tabarc-maximum-upload-file-size' ),
                'error_message'   => '',
            ),
            array(
                'title'           => esc_html__( 'Database Version', 'tabarc-maximum-upload-file-size' ),
                'version'         => $this->wpdb->db_version(),
                'status'          => 1,
                'success_message' => esc_html__( '- ok', 'tabarc-maximum-upload-file-size' ),
                'error_message'   => '',
            ),
            array(
                'title'           => esc_html__( 'Table Prefix', 'tabarc-maximum-upload-file-size' ),
                'version'         => $this->wpdb->prefix,
                'status'          => 1,
                'success_message' => esc_html__( '- ok', 'tabarc-maximum-upload-file-size' ),
                'error_message'   => '',
            ),
        );
    }
}

