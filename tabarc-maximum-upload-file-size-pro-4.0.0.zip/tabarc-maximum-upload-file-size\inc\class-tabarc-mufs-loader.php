<?php

/**
 * Class Class_Max_Uploader_Loader
 */
class Class_Max_Uploader_Loader{
    // Autoload dependency.
    public function __construct(){
        $this->load_dependency();
    }

    /**
     * Load plugin files.
     *
     * Helpers load before the Pro feature class; admin templates rely on both.
     */
    public function load_dependency() {

        include_once(WMUFS_PLUGIN_PATH. 'inc/class-wmufs-i18n.php');
        include_once(WMUFS_PLUGIN_PATH. 'inc/class-wmufs-helper.php');
        include_once(WMUFS_PLUGIN_PATH. 'inc/class-wmufs-pro-features.php');
        include_once(WMUFS_PLUGIN_PATH. 'inc/tabarc-plugin-suggest.php');
        include_once(WMUFS_PLUGIN_PATH. 'inc/hooks.php');
        include_once(WMUFS_PLUGIN_PATH. 'inc/tabarc-promotion.php');
        include_once(WMUFS_PLUGIN_PATH. 'admin/class-wmufs-admin.php');
        include_once(WMUFS_PLUGIN_PATH. 'inc/class-wmufs-chunk-files.php');

    }
}

/**
 * Initialize load class .
 */
function wmufs_run() {
    if ( class_exists( 'Class_Max_Uploader_Loader' ) ) {
        new Class_Max_Uploader_Loader();
    }
}


