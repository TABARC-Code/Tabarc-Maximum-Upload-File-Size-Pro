<?php
/**
 * Plugin Name: Tabarc Maximum Upload File Size Pro
 * Description: Manage WordPress upload limits, role rules, user storage quotas, file type restrictions, upload logs, media size columns, statistics, and CSV reports from one admin screen.
 * Author: Tabarc
 * Author URI: 
 * Plugin URI: 
 * Version: 4.0.0
 * License: GPL2
 * Text Domain: tabarc-maximum-upload-file-size
 * Requires at least: 4.0
 * Tested up to: 6.9
 * Requires PHP: 7.0
 *
 * @copyright: 2026 Tabarc
 **/

define( 'WMUFS_PLUGIN_FILE', __FILE__ );
define( 'WMUFS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'WMUFS_PLUGIN_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'WMUFS_PLUGIN_URL', trailingslashit( plugins_url( '/', __FILE__ ) ) );
define( 'WMUFS_PLUGIN_VERSION', '4.0.0' );
define( 'WMUFS_PRO_VERSION', WMUFS_PLUGIN_VERSION );
define( 'WMUFS_INTERNAL_VERSION', 'cleanroom-pro-2026.07.29.1' );

/**
 * Version notes, kept in the bootstrap because future me will look here first.
 *
 * 1.x answered one question: "why is WordPress refusing my file?"
 * 2.x added system health and memory controls, which saved a few support emails.
 * 3.x brought role limits. Useful, though the admin UI still had that cupboard-under-
 * the-stairs feeling.
 * 4.x is the cleanroom Pro rebuild: logging, quotas, restrictions, media columns,
 * statistics, reporting, and fewer sales banners pretending to be product design.
 */
require_once WMUFS_PLUGIN_PATH . 'inc/class-tabarc-mufs-loader.php';

if ( function_exists( 'wmufs_run' ) ) {
        wmufs_run();
}
