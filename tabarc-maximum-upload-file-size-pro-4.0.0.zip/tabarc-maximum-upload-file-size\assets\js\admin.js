(function ($) {
    "use strict";

    $(document).ready(function () {
        $('#hideWmufsNotice').on('click', function () {
            $.ajax({
                url: wmufs_admin_notice_ajax_object.wmufs_admin_notice_ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'wmufs_admin_notice_ajax_object_save',
                    data: 1,
                    _ajax_nonce: wmufs_admin_notice_ajax_object.nonce
                },
                success: function (response) {
                    if (response.success === true) {
                        $('.hideWmufsNotice').hide('fast');
                    }
                }
            });
        });

        function showTab(tabId) {
            $('.tabarc-mufs-tab-link').removeClass('nav-tab-active');
            $('.tabarc-mufs-tab-link[data-tab="' + tabId + '"]').addClass('nav-tab-active');
            $('.tabarc-mufs-tab-content').hide();
            $('#tabarc-mufs-tab-' + tabId).show();
        }

        $('.tabarc-mufs-tab-link').on('click', function (e) {
            e.preventDefault();

            const tabId = $(this).data('tab');
            showTab(tabId);

            const newUrl = new URL(window.location.href);
            newUrl.searchParams.set('tab', tabId);
            history.pushState({ tab: tabId }, '', newUrl);
        });

        $(window).on('popstate', function (event) {
            const state = event.originalEvent.state;
            const tabId = state && state.tab ? state.tab : (new URLSearchParams(window.location.search).get('tab') || 'general');
            showTab(tabId);
        });

        const initialTab = new URLSearchParams(window.location.search).get('tab') || wmufs_admin_notice_ajax_object.active_tab || 'general';
        showTab(initialTab);
    });
})(jQuery);