<?php
/**
 * Pro feature layer for Tabarc Maximum Upload File Size.
 *
 * This GitHub build is the full tool: upload logs, storage quotas, file type
 * restrictions, media library columns, simple statistics, and CSV export. No
 * payment links. No gated-feature theatre.
 *
 * Future idea: move the upload log table behind a tiny repository class if it
 * grows another screen. Right now that would be architecture cosplay.
 *
 * @package Tabarc MUFS
 */

if (!defined('ABSPATH')) {
    exit;
}

class WMUFS_Pro_Features {

    const OPTION_VERSION = 'wmufs_internal_version';
    const OPTION_USER_LIMITS = 'wmufs_user_storage_limits';
    const OPTION_FILE_TYPES = 'wmufs_file_type_rules';
    const LOG_TABLE_VERSION = '4.0.0';

    public static function init() {
        add_action('init', array(__CLASS__, 'maybe_upgrade'), 5);
        add_action('admin_init', array(__CLASS__, 'handle_user_limits_submission'));
        add_action('admin_init', array(__CLASS__, 'handle_file_type_submission'));
        add_action('admin_post_wmufs_export_upload_logs', array(__CLASS__, 'export_upload_logs'));
        add_action('admin_post_wmufs_clear_upload_logs', array(__CLASS__, 'clear_upload_logs'));

        add_filter('wmufs_admin_tabs', array(__CLASS__, 'add_admin_tabs'));
        add_action('wmufs_admin_tab_content', array(__CLASS__, 'render_admin_tab'));

        add_filter('wp_handle_upload_prefilter', array(__CLASS__, 'enforce_upload_rules'));
        add_action('add_attachment', array(__CLASS__, 'record_attachment_upload'));
        add_filter('manage_media_columns', array(__CLASS__, 'add_media_columns'));
        add_action('manage_media_custom_column', array(__CLASS__, 'render_media_column'), 10, 2);
        add_filter('attachment_fields_to_edit', array(__CLASS__, 'attachment_detail_fields'), 10, 2);
    }

    public static function activate() {
        self::create_log_table();
        update_option(self::OPTION_VERSION, WMUFS_INTERNAL_VERSION);
    }

    public static function maybe_upgrade() {
        if (get_option(self::OPTION_VERSION) !== WMUFS_INTERNAL_VERSION) {
            self::create_log_table();
            update_option(self::OPTION_VERSION, WMUFS_INTERNAL_VERSION);
        }
    }

    public static function add_admin_tabs($tabs) {
        $ordered = array();

        foreach ($tabs as $key => $label) {
            $ordered[$key] = $label;

            if ($key === 'general') {
                $ordered['features'] = __('Features at a Glance', 'tabarc-maximum-upload-file-size');
                $ordered['upload_logs'] = __('Upload Logs', 'tabarc-maximum-upload-file-size');
                $ordered['user_limits'] = __('User Storage Limits', 'tabarc-maximum-upload-file-size');
                $ordered['file_types'] = __('File Type Rules', 'tabarc-maximum-upload-file-size');
                $ordered['media_manager'] = __('Media Manager', 'tabarc-maximum-upload-file-size');
                $ordered['statistics'] = __('Statistics', 'tabarc-maximum-upload-file-size');
                $ordered['reports'] = __('Reports', 'tabarc-maximum-upload-file-size');
            }
        }

        return $ordered;
    }

    public static function render_admin_tab($tab_key) {
        $templates = array(
            'features' => 'admin/templates/TopFeatures.php',
            'upload_logs' => 'admin/templates/UploadLogs.php',
            'user_limits' => 'admin/templates/UserStorageLimits.php',
            'file_types' => 'admin/templates/FileTypeRestrictions.php',
            'media_manager' => 'admin/templates/MediaManager.php',
            'statistics' => 'admin/templates/UploadStatistics.php',
            'reports' => 'admin/templates/AdvancedReports.php',
        );

        if (isset($templates[$tab_key])) {
            include WMUFS_PLUGIN_PATH . $templates[$tab_key];
        }
    }

    public static function handle_user_limits_submission() {
        if (!isset($_POST['wmufs_user_limits_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wmufs_user_limits_nonce'])), 'wmufs_user_limits_action')) {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to change upload limits.', 'tabarc-maximum-upload-file-size'));
        }

        $limits = array();

        if (isset($_POST['user_limits']) && is_array($_POST['user_limits'])) {
            foreach ($_POST['user_limits'] as $user_id => $limit_mb) {
                $user_id = absint($user_id);
                $limit_mb = (int) sanitize_text_field(wp_unslash($limit_mb));

                if ($user_id > 0 && $limit_mb > 0) {
                    $limits[$user_id] = $limit_mb * MB_IN_BYTES;
                }
            }
        }

        update_option(self::OPTION_USER_LIMITS, $limits);
        set_transient('wmufs_settings_updated', __('User storage limits saved.', 'tabarc-maximum-upload-file-size'), 30);
        wp_safe_redirect(admin_url('admin.php?page=easy_media&tab=user_limits'));
        exit;
    }

    public static function handle_file_type_submission() {
        if (!isset($_POST['wmufs_file_types_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wmufs_file_types_nonce'])), 'wmufs_file_types_action')) {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to change file type rules.', 'tabarc-maximum-upload-file-size'));
        }

        $rules = array('roles' => array(), 'users' => array());

        if (isset($_POST['role_file_types']) && is_array($_POST['role_file_types'])) {
            foreach ($_POST['role_file_types'] as $role => $extensions) {
                $role = sanitize_key($role);
                $extensions = self::normalise_extension_list($extensions);

                if ($role && !empty($extensions)) {
                    $rules['roles'][$role] = $extensions;
                }
            }
        }

        if (isset($_POST['user_file_types']) && is_array($_POST['user_file_types'])) {
            foreach ($_POST['user_file_types'] as $user_id => $extensions) {
                $user_id = absint($user_id);
                $extensions = self::normalise_extension_list($extensions);

                if ($user_id > 0 && !empty($extensions)) {
                    $rules['users'][$user_id] = $extensions;
                }
            }
        }

        update_option(self::OPTION_FILE_TYPES, $rules);
        set_transient('wmufs_settings_updated', __('File type rules saved.', 'tabarc-maximum-upload-file-size'), 30);
        wp_safe_redirect(admin_url('admin.php?page=easy_media&tab=file_types'));
        exit;
    }

    public static function enforce_upload_rules($file) {
        if (!is_user_logged_in()) {
            return $file;
        }

        $user_id = get_current_user_id();
        $file_size = isset($file['size']) ? (int) $file['size'] : 0;
        $file_name = isset($file['name']) ? (string) $file['name'] : '';
        $extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed_extensions = self::get_allowed_extensions_for_user($user_id);
        if (!empty($allowed_extensions) && !in_array($extension, $allowed_extensions, true)) {
            $file['error'] = sprintf(
                __('Files ending in .%1$s are not allowed for this account. Allowed types: %2$s.', 'tabarc-maximum-upload-file-size'),
                esc_html($extension),
                esc_html(implode(', ', $allowed_extensions))
            );
            return $file;
        }

        $limit = self::get_user_storage_limit($user_id);
        if ($limit > 0) {
            $used = self::get_user_storage_used($user_id);

            if (($used + $file_size) > $limit) {
                $file['error'] = sprintf(
                    __('This upload would exceed the user storage limit. Used: %1$s. Limit: %2$s.', 'tabarc-maximum-upload-file-size'),
                    WMUFS_Helper::format_bytes($used),
                    WMUFS_Helper::format_bytes($limit)
                );
            }
        }

        return $file;
    }

    public static function record_attachment_upload($attachment_id) {
        $file_path = get_attached_file($attachment_id);
        $file_size = ($file_path && file_exists($file_path)) ? filesize($file_path) : 0;
        $mime_type = get_post_mime_type($attachment_id);
        $file_name = $file_path ? wp_basename($file_path) : get_the_title($attachment_id);
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $attachment = get_post($attachment_id);
        $user_id = $attachment ? (int) $attachment->post_author : get_current_user_id();

        update_post_meta($attachment_id, '_wmufs_file_size', (int) $file_size);

        global $wpdb;
        $wpdb->insert(
            self::get_log_table_name(),
            array(
                'attachment_id' => (int) $attachment_id,
                'user_id' => (int) $user_id,
                'file_name' => sanitize_file_name($file_name),
                'file_size' => (int) $file_size,
                'file_type' => sanitize_key($file_type),
                'mime_type' => sanitize_text_field($mime_type),
                'upload_source' => sanitize_text_field(self::detect_upload_source()),
                'uploaded_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s', '%s', '%s')
        );
    }

    public static function add_media_columns($columns) {
        $columns['wmufs_file_size'] = __('File Size', 'tabarc-maximum-upload-file-size');
        $columns['wmufs_uploaded_by'] = __('Uploaded By', 'tabarc-maximum-upload-file-size');
        return $columns;
    }

    public static function render_media_column($column_name, $post_id) {
        if ($column_name === 'wmufs_file_size') {
            echo esc_html(WMUFS_Helper::format_bytes(self::get_attachment_file_size($post_id)));
        }

        if ($column_name === 'wmufs_uploaded_by') {
            $post = get_post($post_id);
            $user = $post ? get_userdata($post->post_author) : false;
            echo $user ? esc_html($user->display_name) : esc_html__('Unknown', 'tabarc-maximum-upload-file-size');
        }
    }

    public static function attachment_detail_fields($form_fields, $post) {
        $usage = self::get_attachment_usage($post->ID, 5);
        $count = count($usage);

        $form_fields['wmufs_file_size'] = array(
            'label' => __('File Size', 'tabarc-maximum-upload-file-size'),
            'input' => 'html',
            'html' => esc_html(WMUFS_Helper::format_bytes(self::get_attachment_file_size($post->ID))),
        );

        $form_fields['wmufs_usage'] = array(
            'label' => __('Detected Usage', 'tabarc-maximum-upload-file-size'),
            'input' => 'html',
            'html' => esc_html(sprintf(_n('%d place found', '%d places found', $count, 'tabarc-maximum-upload-file-size'), $count)),
        );

        return $form_fields;
    }

    public static function export_upload_logs() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to export upload logs.', 'tabarc-maximum-upload-file-size'));
        }

        check_admin_referer('wmufs_export_upload_logs');

        $logs = self::get_upload_logs(0);
        $filename = 'tabarc-upload-logs-' . gmdate('Y-m-d') . '.csv';

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);

        $output = fopen('php://output', 'w');
        fputcsv($output, array('Date', 'User', 'File Name', 'Size', 'Extension', 'MIME Type', 'Attachment ID', 'Detected Usage'));

        foreach ($logs as $log) {
            $user = $log->user_id ? get_userdata($log->user_id) : false;
            $usage = self::get_attachment_usage((int) $log->attachment_id, 20);
            $usage_titles = array();

            foreach ($usage as $item) {
                $usage_titles[] = $item['label'];
            }

            fputcsv($output, array(
                $log->uploaded_at,
                $user ? $user->display_name : __('Unknown', 'tabarc-maximum-upload-file-size'),
                $log->file_name,
                WMUFS_Helper::format_bytes($log->file_size),
                $log->file_type,
                $log->mime_type,
                $log->attachment_id,
                implode('; ', $usage_titles),
            ));
        }

        fclose($output);
        exit;
    }

    public static function clear_upload_logs() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to clear upload logs.', 'tabarc-maximum-upload-file-size'));
        }

        check_admin_referer('wmufs_clear_upload_logs');

        global $wpdb;
        $wpdb->query('TRUNCATE TABLE ' . self::get_log_table_name());

        set_transient('wmufs_settings_updated', __('Upload logs cleared.', 'tabarc-maximum-upload-file-size'), 30);
        wp_safe_redirect(admin_url('admin.php?page=easy_media&tab=reports'));
        exit;
    }

    public static function get_upload_logs($limit = 50) {
        global $wpdb;

        $table = self::get_log_table_name();
        $limit = (int) $limit;

        if ($limit > 0) {
            return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} ORDER BY uploaded_at DESC, id DESC LIMIT %d", $limit));
        }

        return $wpdb->get_results("SELECT * FROM {$table} ORDER BY uploaded_at DESC, id DESC");
    }

    public static function get_statistics() {
        global $wpdb;

        $table = self::get_log_table_name();

        return array(
            'total_uploads' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}"),
            'total_size' => (int) $wpdb->get_var("SELECT COALESCE(SUM(file_size), 0) FROM {$table}"),
            'top_uploaders' => $wpdb->get_results("SELECT user_id, COUNT(*) AS uploads, COALESCE(SUM(file_size), 0) AS bytes FROM {$table} GROUP BY user_id ORDER BY bytes DESC LIMIT 5"),
            'top_files' => $wpdb->get_results("SELECT * FROM {$table} ORDER BY file_size DESC LIMIT 5"),
            'recent_files' => self::get_upload_logs(5),
        );
    }

    public static function get_user_limits() {
        $limits = get_option(self::OPTION_USER_LIMITS, array());
        return is_array($limits) ? $limits : array();
    }

    public static function get_file_type_rules() {
        $rules = get_option(self::OPTION_FILE_TYPES, array());

        if (!is_array($rules)) {
            $rules = array();
        }

        return wp_parse_args($rules, array('roles' => array(), 'users' => array()));
    }

    public static function get_user_storage_limit($user_id) {
        $limits = self::get_user_limits();
        $user_id = absint($user_id);
        return isset($limits[$user_id]) ? (int) $limits[$user_id] : 0;
    }

    public static function get_user_storage_used($user_id) {
        $user_id = absint($user_id);

        if ($user_id <= 0) {
            return 0;
        }

        $attachments = get_posts(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'author' => $user_id,
            'posts_per_page' => -1,
            'fields' => 'ids',
        ));

        $total = 0;

        foreach ($attachments as $attachment_id) {
            $total += self::get_attachment_file_size((int) $attachment_id);
        }

        return $total;
    }

    public static function get_upload_users() {
        return get_users(array(
            'fields' => array('ID', 'display_name', 'user_email', 'roles'),
            'orderby' => 'display_name',
            'order' => 'ASC',
        ));
    }

    public static function get_media_items($limit = 50) {
        $items = get_posts(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => (int) $limit,
            'orderby' => 'date',
            'order' => 'DESC',
        ));

        return is_array($items) ? $items : array();
    }

    public static function get_attachment_usage($attachment_id, $limit = 10) {
        global $wpdb;

        $attachment_id = absint($attachment_id);
        $limit = absint($limit);

        if ($attachment_id <= 0) {
            return array();
        }

        $url = wp_get_attachment_url($attachment_id);
        $results = array();

        $featured = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE pm.meta_key = '_thumbnail_id'
             AND pm.meta_value = %d
             AND p.post_status NOT IN ('trash', 'auto-draft')
             LIMIT %d",
            $attachment_id,
            $limit
        ));

        foreach ($featured as $post) {
            $results[$post->ID . '-featured'] = array(
                'id' => (int) $post->ID,
                'label' => sprintf('%s: %s', $post->post_type, get_the_title($post->ID)),
                'context' => __('Featured image', 'tabarc-maximum-upload-file-size'),
                'edit_link' => get_edit_post_link($post->ID, ''),
            );
        }

        if ($url && count($results) < $limit) {
            $remaining = $limit - count($results);
            $content = $wpdb->get_results($wpdb->prepare(
                "SELECT ID, post_title, post_type
                 FROM {$wpdb->posts}
                 WHERE post_content LIKE %s
                 AND post_status NOT IN ('trash', 'auto-draft')
                 LIMIT %d",
                '%' . $wpdb->esc_like($url) . '%',
                $remaining
            ));

            foreach ($content as $post) {
                $results[$post->ID . '-content'] = array(
                    'id' => (int) $post->ID,
                    'label' => sprintf('%s: %s', $post->post_type, get_the_title($post->ID)),
                    'context' => __('Post content', 'tabarc-maximum-upload-file-size'),
                    'edit_link' => get_edit_post_link($post->ID, ''),
                );
            }
        }

        if (count($results) < $limit) {
            $remaining = $limit - count($results);
            $gallery = $wpdb->get_results($wpdb->prepare(
                "SELECT p.ID, p.post_title, p.post_type
                 FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                 WHERE pm.meta_key = '_product_image_gallery'
                 AND CONCAT(',', pm.meta_value, ',') LIKE %s
                 AND p.post_status NOT IN ('trash', 'auto-draft')
                 LIMIT %d",
                '%,' . $wpdb->esc_like((string) $attachment_id) . ',%',
                $remaining
            ));

            foreach ($gallery as $post) {
                $results[$post->ID . '-gallery'] = array(
                    'id' => (int) $post->ID,
                    'label' => sprintf('%s: %s', $post->post_type, get_the_title($post->ID)),
                    'context' => __('Product gallery', 'tabarc-maximum-upload-file-size'),
                    'edit_link' => get_edit_post_link($post->ID, ''),
                );
            }
        }

        return array_values($results);
    }

    public static function get_export_url() {
        return wp_nonce_url(admin_url('admin-post.php?action=wmufs_export_upload_logs'), 'wmufs_export_upload_logs');
    }

    public static function get_clear_logs_url() {
        return wp_nonce_url(admin_url('admin-post.php?action=wmufs_clear_upload_logs'), 'wmufs_clear_upload_logs');
    }

    public static function get_attachment_file_size($attachment_id) {
        $size = (int) get_post_meta($attachment_id, '_wmufs_file_size', true);

        if ($size > 0) {
            return $size;
        }

        $file = get_attached_file($attachment_id);
        $size = ($file && file_exists($file)) ? (int) filesize($file) : 0;

        if ($size > 0) {
            update_post_meta($attachment_id, '_wmufs_file_size', $size);
        }

        return $size;
    }

    private static function create_log_table() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = self::get_log_table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            file_name varchar(255) NOT NULL DEFAULT '',
            file_size bigint(20) unsigned NOT NULL DEFAULT 0,
            file_type varchar(40) NOT NULL DEFAULT '',
            mime_type varchar(100) NOT NULL DEFAULT '',
            upload_source varchar(100) NOT NULL DEFAULT '',
            uploaded_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
            PRIMARY KEY  (id),
            KEY attachment_id (attachment_id),
            KEY user_id (user_id),
            KEY uploaded_at (uploaded_at)
        ) {$charset_collate};";

        dbDelta($sql);
        update_option('wmufs_log_table_version', self::LOG_TABLE_VERSION);
    }

    private static function get_log_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'wmufs_upload_logs';
    }

    private static function normalise_extension_list($extensions) {
        if (is_array($extensions)) {
            $extensions = implode(',', $extensions);
        }

        $extensions = sanitize_text_field(wp_unslash($extensions));
        $parts = preg_split('/[\s,]+/', strtolower($extensions));
        $clean = array();

        foreach ($parts as $part) {
            $part = trim($part, " .\t\n\r\0\x0B");

            if ($part !== '' && preg_match('/^[a-z0-9]+$/', $part)) {
                $clean[] = $part;
            }
        }

        return array_values(array_unique($clean));
    }

    private static function get_allowed_extensions_for_user($user_id) {
        $rules = self::get_file_type_rules();
        $user_id = absint($user_id);

        if (isset($rules['users'][$user_id]) && is_array($rules['users'][$user_id])) {
            return $rules['users'][$user_id];
        }

        $user = get_userdata($user_id);
        if (!$user || empty($user->roles)) {
            return array();
        }

        foreach ($user->roles as $role) {
            if (isset($rules['roles'][$role]) && is_array($rules['roles'][$role])) {
                return $rules['roles'][$role];
            }
        }

        return array();
    }

    private static function detect_upload_source() {
        if (defined('DOING_AJAX') && DOING_AJAX) {
            return 'ajax-media-uploader';
        }

        if (is_admin()) {
            return 'admin';
        }

        return 'front-end';
    }
}

add_action('plugins_loaded', array('WMUFS_Pro_Features', 'init'));
register_activation_hook(WMUFS_PLUGIN_FILE, array('WMUFS_Pro_Features', 'activate'));