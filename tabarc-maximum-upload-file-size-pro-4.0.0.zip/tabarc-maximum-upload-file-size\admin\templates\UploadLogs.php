<?php
$logs = WMUFS_Pro_Features::get_upload_logs(50);
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-list-view" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('Upload Logs', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <p><?php esc_html_e('Recent uploads are listed with user, size, type, timestamp, and detected usage. The usage finder checks the obvious WordPress places first, because crawling every page builder fragment on every request would be rude.', 'tabarc-maximum-upload-file-size'); ?></p>
                <p><a class="button button-primary" href="<?php echo esc_url(WMUFS_Pro_Features::get_export_url()); ?>"><?php esc_html_e('Export CSV', 'tabarc-maximum-upload-file-size'); ?></a></p>
                <table class="wp-list-table widefat fixed striped wmufs-data-table">
                    <thead>
                    <tr>
                        <th><?php esc_html_e('Uploaded', 'tabarc-maximum-upload-file-size'); ?></th>
                        <th><?php esc_html_e('User', 'tabarc-maximum-upload-file-size'); ?></th>
                        <th><?php esc_html_e('File', 'tabarc-maximum-upload-file-size'); ?></th>
                        <th><?php esc_html_e('Size', 'tabarc-maximum-upload-file-size'); ?></th>
                        <th><?php esc_html_e('Type', 'tabarc-maximum-upload-file-size'); ?></th>
                        <th><?php esc_html_e('Usage', 'tabarc-maximum-upload-file-size'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($logs)) : ?>
                        <tr><td colspan="6"><?php esc_html_e('No upload logs yet. Upload a file and this table will stop looking so philosophical.', 'tabarc-maximum-upload-file-size'); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ($logs as $log) : ?>
                            <?php
                            $user = $log->user_id ? get_userdata($log->user_id) : false;
                            $usage = WMUFS_Pro_Features::get_attachment_usage((int) $log->attachment_id, 3);
                            ?>
                            <tr>
                                <td><?php echo esc_html(mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $log->uploaded_at)); ?></td>
                                <td><?php echo $user ? esc_html($user->display_name) : esc_html__('Unknown', 'tabarc-maximum-upload-file-size'); ?></td>
                                <td><?php echo esc_html($log->file_name); ?></td>
                                <td><?php echo esc_html(WMUFS_Helper::format_bytes($log->file_size)); ?></td>
                                <td><?php echo esc_html($log->file_type ? $log->file_type : $log->mime_type); ?></td>
                                <td>
                                    <?php if (empty($usage)) : ?>
                                        <?php esc_html_e('No obvious usage found', 'tabarc-maximum-upload-file-size'); ?>
                                    <?php else : ?>
                                        <ul class="wmufs-usage-list">
                                            <?php foreach ($usage as $item) : ?>
                                                <li>
                                                    <?php if (!empty($item['edit_link'])) : ?>
                                                        <a href="<?php echo esc_url($item['edit_link']); ?>"><?php echo esc_html($item['label']); ?></a>
                                                    <?php else : ?>
                                                        <?php echo esc_html($item['label']); ?>
                                                    <?php endif; ?>
                                                    <span><?php echo esc_html($item['context']); ?></span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>