<?php
$stats = WMUFS_Pro_Features::get_statistics();
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-chart-area" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('Upload Statistics', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <div class="wmufs-stat-grid">
                    <div class="wmufs-stat-card"><strong><?php echo esc_html(number_format_i18n($stats['total_uploads'])); ?></strong><span><?php esc_html_e('Logged Uploads', 'tabarc-maximum-upload-file-size'); ?></span></div>
                    <div class="wmufs-stat-card"><strong><?php echo esc_html(WMUFS_Helper::format_bytes($stats['total_size'])); ?></strong><span><?php esc_html_e('Logged Storage', 'tabarc-maximum-upload-file-size'); ?></span></div>
                    <div class="wmufs-stat-card"><strong><?php echo esc_html(WMUFS_PLUGIN_VERSION); ?></strong><span><?php esc_html_e('Plugin Version', 'tabarc-maximum-upload-file-size'); ?></span></div>
                </div>

                <h2><?php esc_html_e('Top Uploaders', 'tabarc-maximum-upload-file-size'); ?></h2>
                <table class="wp-list-table widefat fixed striped wmufs-data-table">
                    <thead><tr><th><?php esc_html_e('User', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Uploads', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Storage', 'tabarc-maximum-upload-file-size'); ?></th></tr></thead>
                    <tbody>
                    <?php if (empty($stats['top_uploaders'])) : ?>
                        <tr><td colspan="3"><?php esc_html_e('No logged uploads yet.', 'tabarc-maximum-upload-file-size'); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ($stats['top_uploaders'] as $row) : ?>
                            <?php $user = $row->user_id ? get_userdata($row->user_id) : false; ?>
                            <tr><td><?php echo $user ? esc_html($user->display_name) : esc_html__('Unknown', 'tabarc-maximum-upload-file-size'); ?></td><td><?php echo esc_html(number_format_i18n($row->uploads)); ?></td><td><?php echo esc_html(WMUFS_Helper::format_bytes($row->bytes)); ?></td></tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>

                <h2><?php esc_html_e('Largest Logged Files', 'tabarc-maximum-upload-file-size'); ?></h2>
                <table class="wp-list-table widefat fixed striped wmufs-data-table">
                    <thead><tr><th><?php esc_html_e('File', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Size', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Uploaded', 'tabarc-maximum-upload-file-size'); ?></th></tr></thead>
                    <tbody>
                    <?php if (empty($stats['top_files'])) : ?>
                        <tr><td colspan="3"><?php esc_html_e('No files to rank yet.', 'tabarc-maximum-upload-file-size'); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ($stats['top_files'] as $file) : ?>
                            <tr><td><?php echo esc_html($file->file_name); ?></td><td><?php echo esc_html(WMUFS_Helper::format_bytes($file->file_size)); ?></td><td><?php echo esc_html(mysql2date(get_option('date_format'), $file->uploaded_at)); ?></td></tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>