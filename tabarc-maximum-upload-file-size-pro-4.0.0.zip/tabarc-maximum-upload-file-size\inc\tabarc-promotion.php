<?php
// Dashboard widget and admin notice promotion removed.
