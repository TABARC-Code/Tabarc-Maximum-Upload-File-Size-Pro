<?php
$logs = WMUFS_Pro_Features::get_upload_logs(5);
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-media-spreadsheet" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('Advanced Reports', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <div class="wmufs-report-actions">
                    <a class="button button-primary" href="<?php echo esc_url(WMUFS_Pro_Features::get_export_url()); ?>"><?php esc_html_e('Export Upload Logs as CSV', 'tabarc-maximum-upload-file-size'); ?></a>
                    <a class="button wmufs-danger-link" href="<?php echo esc_url(WMUFS_Pro_Features::get_clear_logs_url()); ?>" onclick="return confirm('<?php echo esc_js(__('Clear upload logs?', 'tabarc-maximum-upload-file-size')); ?>');"><?php esc_html_e('Clear Upload Logs', 'tabarc-maximum-upload-file-size'); ?></a>
                </div>
                <p><?php esc_html_e('CSV export includes date, user, file name, size, extension, MIME type, attachment ID, and detected usage. Boring columns, deliberately. Reports should be useful before they are decorative.', 'tabarc-maximum-upload-file-size'); ?></p>

                <h2><?php esc_html_e('Recent Export Preview', 'tabarc-maximum-upload-file-size'); ?></h2>
                <table class="wp-list-table widefat fixed striped wmufs-data-table">
                    <thead><tr><th><?php esc_html_e('Date', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('File', 'tabarc-maximum-upload-file-size'); ?></th><th><?php esc_html_e('Size', 'tabarc-maximum-upload-file-size'); ?></th></tr></thead>
                    <tbody>
                    <?php if (empty($logs)) : ?>
                        <tr><td colspan="3"><?php esc_html_e('No log rows to preview.', 'tabarc-maximum-upload-file-size'); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ($logs as $log) : ?>
                            <tr><td><?php echo esc_html(mysql2date(get_option('date_format'), $log->uploaded_at)); ?></td><td><?php echo esc_html($log->file_name); ?></td><td><?php echo esc_html(WMUFS_Helper::format_bytes($log->file_size)); ?></td></tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>