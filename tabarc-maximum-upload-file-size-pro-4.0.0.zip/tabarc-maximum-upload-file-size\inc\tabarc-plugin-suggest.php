<?php
// Cross-promotion plugin suggestion removed.
