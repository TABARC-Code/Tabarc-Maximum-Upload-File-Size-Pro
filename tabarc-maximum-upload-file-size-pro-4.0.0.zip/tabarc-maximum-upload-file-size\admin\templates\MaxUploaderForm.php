<?php
$tabarc_mufs_settings = get_option('wmufs_settings', array());
if (!is_array($tabarc_mufs_settings)) {
    $tabarc_mufs_settings = array();
}

$max_size = isset($tabarc_mufs_settings['max_limits']['all']) ? (int) $tabarc_mufs_settings['max_limits']['all'] : wp_max_upload_size();
$max_size = $max_size / MB_IN_BYTES;
$wp_default_limit = wp_max_upload_size() / MB_IN_BYTES;

$size_options = array(
    '2' => '2 MB',
    '4' => '4 MB',
    '8' => '8 MB',
    '16' => '16 MB',
    '32' => '32 MB',
    '40' => '40 MB',
    '64' => '64 MB',
    '128' => '128 MB',
    '256' => '256 MB',
    '512' => '512 MB',
    '1024' => '1 GB',
    '2048' => '2 GB',
    '3072' => '3 GB',
    '4096' => '4 GB',
    '5120' => '5 GB',
    '10240' => '10 GB',
);

if (!isset($size_options[(string) $wp_default_limit]) && $wp_default_limit > 0) {
    $size_options[(string) $wp_default_limit] = 'Server default (' . round($wp_default_limit) . ' MB)';
    ksort($size_options, SORT_NUMERIC);
}

$wpufs_max_execution_time = isset($tabarc_mufs_settings['max_execution_time']) ? (int) $tabarc_mufs_settings['max_execution_time'] : (int) ini_get('max_execution_time');

$memory_limit_mb = isset($tabarc_mufs_settings['max_memory_limit']) ? (int) $tabarc_mufs_settings['max_memory_limit'] / MB_IN_BYTES : ini_get('memory_limit');
if ($memory_limit_mb && preg_match('/(\d+)([KMG]?)/i', (string) $memory_limit_mb, $matches)) {
    $value = (int) $matches[1];
    $unit = strtoupper($matches[2]);

    if ($unit === 'G') {
        $memory_limit_mb = $value * 1024;
    } elseif ($unit === 'K') {
        $memory_limit_mb = (int) ($value / 1024);
    } else {
        $memory_limit_mb = $value;
    }
}

if (!isset($size_options[(string) $memory_limit_mb]) && $memory_limit_mb > 0) {
    $size_options[(string) $memory_limit_mb] = ($memory_limit_mb >= 1024) ? ($memory_limit_mb / 1024) . ' GB' : $memory_limit_mb . ' MB';
    ksort($size_options, SORT_NUMERIC);
}

$wmufs_limit_type = isset($tabarc_mufs_settings['limit_type']) ? $tabarc_mufs_settings['limit_type'] : 'global';
$roles = WMUFS_Helper::get_available_roles();
$role_limits = WMUFS_Helper::get_role_limits();
?>

<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-admin-settings" style="font-size: inherit; line-height: unset;"></span>
        <?php esc_html_e('Control Upload Limits', 'tabarc-maximum-upload-file-size'); ?>
    </h1><br>

    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8 wmufs_form_centered">
                <div class="wmufs_inner_form_box">
                    <div class="wmufs-card wmufs-version-note">
                        <h2><?php esc_html_e('Top Features at a Glance', 'tabarc-maximum-upload-file-size'); ?></h2>
                        <p><?php esc_html_e('Version 4.0.0 keeps the upload limit controls and adds logs, storage quotas, type rules, media size columns, statistics, and CSV reports. It is the build the plugin was trying to become before the old locked screens got in the way.', 'tabarc-maximum-upload-file-size'); ?></p>
                    </div>

                    <div class="wmufs-card wmufs-toggle-card">
                        <h3 class="wmufs-card-title"><?php esc_html_e('Select Upload Limit Mode', 'tabarc-maximum-upload-file-size'); ?></h3>

                        <div class="wmufs-toggle-buttons">
                            <button type="button" class="wmufs-toggle-btn <?php echo $wmufs_limit_type === 'global' ? 'active' : ''; ?>" data-target="#all-users-section"><?php esc_html_e('Global Limit', 'tabarc-maximum-upload-file-size'); ?></button>
                            <button type="button" class="wmufs-toggle-btn <?php echo $wmufs_limit_type === 'role_based' ? 'active' : ''; ?>" data-target="#role-based-section"><?php esc_html_e('Role-Based Limit', 'tabarc-maximum-upload-file-size'); ?></button>
                        </div>

                        <div id="all-users-section" class="wmufs-toggle-section">
                            <form method="post">
                                <input type="hidden" name="type" value="global">
                                <h2><?php esc_html_e('Apply Upload Limit for All Users', 'tabarc-maximum-upload-file-size'); ?></h2>
                                <table class="form-table">
                                    <tbody>
                                    <tr>
                                        <th scope="row"><label for="max_file_size_field"><?php esc_html_e('Site Global Limit', 'tabarc-maximum-upload-file-size'); ?></label></th>
                                        <td>
                                            <select id="max_file_size_field" name="max_file_size_field">
                                                <?php foreach ($size_options as $key => $size) : ?>
                                                    <option value="<?php echo esc_attr($key); ?>" <?php selected((float) $key, (float) $max_size); ?>><?php echo esc_html($size); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="max_execution_time_field"><?php esc_html_e('Execution Time', 'tabarc-maximum-upload-file-size'); ?></label></th>
                                        <td>
                                            <input id="max_execution_time_field" name="max_execution_time_field" type="number" min="0" value="<?php echo esc_attr($wpufs_max_execution_time); ?>">
                                            <br><small><?php esc_html_e('Typical values: 300, 600, 1800, or 3600 seconds.', 'tabarc-maximum-upload-file-size'); ?></small>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><label for="max_memory_limit_field"><?php esc_html_e('Memory Limit', 'tabarc-maximum-upload-file-size'); ?></label></th>
                                        <td>
                                            <select id="max_memory_limit_field" name="max_memory_limit_field">
                                                <?php foreach ($size_options as $key => $label) : ?>
                                                    <option value="<?php echo esc_attr($key); ?>" <?php selected((float) $key, (float) $memory_limit_mb); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <?php if ((int) $memory_limit_mb > 4096) : ?>
                                                <p class="wmufs-warning"><?php esc_html_e('Warning: memory limits above 4 GB can upset shared hosting. Sometimes the ceiling is there for a reason.', 'tabarc-maximum-upload-file-size'); ?></p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                                <?php wp_nonce_field('easy_media_set_size_action', 'easy_media_set_size_limit'); ?>
                                <?php submit_button(__('Save Global Limit', 'tabarc-maximum-upload-file-size')); ?>
                            </form>
                        </div>

                        <div id="role-based-section" class="wmufs-toggle-section" style="display:none;">
                            <form id="role-limits-form" method="post">
                                <input type="hidden" name="type" value="role_based">
                                <h2><?php esc_html_e('Role-Based Upload Limits', 'tabarc-maximum-upload-file-size'); ?></h2>
                                <p><?php esc_html_e('Set per-file upload limits by role. User storage quotas live in their own tab so the two ideas do not trip over each other.', 'tabarc-maximum-upload-file-size'); ?></p>
                                <table class="wp-list-table widefat fixed striped">
                                    <thead>
                                    <tr>
                                        <th><?php esc_html_e('Role', 'tabarc-maximum-upload-file-size'); ?></th>
                                        <th><?php esc_html_e('Display Name', 'tabarc-maximum-upload-file-size'); ?></th>
                                        <th><?php esc_html_e('Upload Limit', 'tabarc-maximum-upload-file-size'); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($roles as $role_key => $role_data) : ?>
                                        <?php $current_limit = isset($role_limits[$role_key]) ? (int) $role_limits[$role_key] / MB_IN_BYTES : $wp_default_limit; ?>
                                        <tr>
                                            <td><?php echo esc_html($role_key); ?></td>
                                            <td><?php echo esc_html($role_data['name']); ?></td>
                                            <td>
                                                <select name="role_limits[<?php echo esc_attr($role_key); ?>]">
                                                    <?php foreach ($size_options as $key => $label) : ?>
                                                        <option value="<?php echo esc_attr($key); ?>" <?php selected((float) $current_limit, (float) $key); ?>><?php echo esc_html($label); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <?php wp_nonce_field('easy_media_set_size_action', 'easy_media_set_size_limit'); ?>
                                <?php submit_button(__('Save Role Limits', 'tabarc-maximum-upload-file-size')); ?>
                            </form>
                        </div>
                    </div>

                    <div class="wmufs-card wmufs-toggle-card">
                        <h3 class="wmufs-card-title"><?php esc_html_e('Reset Settings', 'tabarc-maximum-upload-file-size'); ?></h3>
                        <p><?php esc_html_e('Reset upload limits, execution time, memory limit, user quotas, and file type rules. Upload logs are kept unless you clear them from Reports.', 'tabarc-maximum-upload-file-size'); ?></p>
                        <p class="submit">
                            <button type="button" id="restore-default-settings" class="button button-secondary wmufs-danger-button">
                                <span class="dashicons dashicons-undo" style="vertical-align: middle; margin-right: 5px;"></span>
                                <?php esc_html_e('Restore Default Settings', 'tabarc-maximum-upload-file-size'); ?>
                            </button>
                        </p>
                    </div>

                    <div class="wmufs_faq_section">
                        <h2><?php esc_html_e('Notes from the Workbench', 'tabarc-maximum-upload-file-size'); ?></h2>
                        <div class="wmufs_faq_item">
                            <strong><?php esc_html_e('What if I set a limit higher than the server allows?', 'tabarc-maximum-upload-file-size'); ?></strong>
                            <p><?php esc_html_e('The server still wins. The plugin can ask politely; PHP, Nginx, Apache, and your host can still say no.', 'tabarc-maximum-upload-file-size'); ?></p>
                        </div>
                        <div class="wmufs_faq_item">
                            <strong><?php esc_html_e('Why separate role limits and user quotas?', 'tabarc-maximum-upload-file-size'); ?></strong>
                            <p><?php esc_html_e('Role limits cap a single upload. User quotas cap total storage. Mixing those made older versions harder to read than they needed to be.', 'tabarc-maximum-upload-file-size'); ?></p>
                        </div>
                        <div class="wmufs_faq_item">
                            <strong><?php esc_html_e('Future idea', 'tabarc-maximum-upload-file-size'); ?></strong>
                            <p><?php esc_html_e('The next tidy improvement would be a scheduled storage index so very large media libraries do not need to calculate old file sizes on demand.', 'tabarc-maximum-upload-file-size'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toggleButtons = document.querySelectorAll('.wmufs-toggle-btn');
    const toggleSections = document.querySelectorAll('.wmufs-toggle-section');
    const activeType = '<?php echo esc_js($wmufs_limit_type); ?>';
    const activeTarget = activeType === 'role_based' ? '#role-based-section' : '#all-users-section';

    toggleButtons.forEach(function(button) {
        button.classList.toggle('active', button.getAttribute('data-target') === activeTarget);
    });

    toggleSections.forEach(function(section) {
        section.style.display = '#' + section.id === activeTarget ? 'block' : 'none';
    });

    toggleButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            toggleButtons.forEach(function(item) { item.classList.remove('active'); });
            button.classList.add('active');
            toggleSections.forEach(function(section) { section.style.display = 'none'; });

            const targetSection = document.querySelector(button.dataset.target);
            if (targetSection) {
                targetSection.style.display = 'block';
            }
        });
    });

    const restoreButton = document.getElementById('restore-default-settings');
    if (restoreButton) {
        restoreButton.addEventListener('click', function() {
            if (!confirm('<?php echo esc_js(__('Restore default settings?', 'tabarc-maximum-upload-file-size')); ?>')) {
                return;
            }

            const originalText = restoreButton.innerHTML;
            restoreButton.innerHTML = '<span class="dashicons dashicons-update" style="vertical-align: middle; margin-right: 5px; animation: spin 1s linear infinite;"></span><?php echo esc_js(__('Restoring...', 'tabarc-maximum-upload-file-size')); ?>';
            restoreButton.disabled = true;

            jQuery.ajax({
                url: typeof ajaxurl !== 'undefined' ? ajaxurl : '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'wmufs_restore_default_settings',
                    nonce: '<?php echo esc_js(wp_create_nonce('wmufs_restore_defaults')); ?>'
                },
                success: function(data) {
                    if (data.success) {
                        window.location.reload();
                        return;
                    }

                    alert(data.data && data.data.message ? data.data.message : '<?php echo esc_js(__('An error occurred while restoring settings.', 'tabarc-maximum-upload-file-size')); ?>');
                    restoreButton.innerHTML = originalText;
                    restoreButton.disabled = false;
                },
                error: function() {
                    alert('<?php echo esc_js(__('An error occurred while restoring settings.', 'tabarc-maximum-upload-file-size')); ?>');
                    restoreButton.innerHTML = originalText;
                    restoreButton.disabled = false;
                }
            });
        });
    }
});
</script>