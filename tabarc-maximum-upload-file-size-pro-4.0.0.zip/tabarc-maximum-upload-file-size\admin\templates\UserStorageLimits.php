<?php
$users = WMUFS_Pro_Features::get_upload_users();
$limits = WMUFS_Pro_Features::get_user_limits();
?>
<div class="wrap wmufs_mb_50">
    <h1><span class="dashicons dashicons-groups" style="font-size: inherit; line-height: unset;"></span> <?php esc_html_e('User Storage Limits', 'tabarc-maximum-upload-file-size'); ?></h1>
    <div class="wmufs_admin_deashboard">
        <div class="wmufs_row" id="poststuff">
            <div class="wmufs_admin_left wmufs_card wmufs-col-8">
                <form method="post">
                    <p><?php esc_html_e('Set a total storage quota per user. Leave a field empty for no individual quota. Existing files count towards the total.', 'tabarc-maximum-upload-file-size'); ?></p>
                    <table class="wp-list-table widefat fixed striped wmufs-data-table">
                        <thead>
                        <tr>
                            <th><?php esc_html_e('User', 'tabarc-maximum-upload-file-size'); ?></th>
                            <th><?php esc_html_e('Roles', 'tabarc-maximum-upload-file-size'); ?></th>
                            <th><?php esc_html_e('Used', 'tabarc-maximum-upload-file-size'); ?></th>
                            <th><?php esc_html_e('Limit (MB)', 'tabarc-maximum-upload-file-size'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($users as $user) : ?>
                            <?php
                            $used = WMUFS_Pro_Features::get_user_storage_used($user->ID);
                            $limit_mb = isset($limits[$user->ID]) ? (int) $limits[$user->ID] / MB_IN_BYTES : '';
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($user->display_name); ?></strong><br><small><?php echo esc_html($user->user_email); ?></small></td>
                                <td><?php echo esc_html(implode(', ', $user->roles)); ?></td>
                                <td><?php echo esc_html(WMUFS_Helper::format_bytes($used)); ?></td>
                                <td><input type="number" min="0" name="user_limits[<?php echo esc_attr($user->ID); ?>]" value="<?php echo esc_attr($limit_mb); ?>" placeholder="<?php esc_attr_e('No limit', 'tabarc-maximum-upload-file-size'); ?>"></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php wp_nonce_field('wmufs_user_limits_action', 'wmufs_user_limits_nonce'); ?>
                    <?php submit_button(__('Save User Limits', 'tabarc-maximum-upload-file-size')); ?>
                </form>
            </div>
            <div class="wmufs_admin_right_sidebar wmufs_card wmufs-col-4">
                <?php include WMUFS_PLUGIN_PATH . 'admin/templates/class-wmufs-sidebar.php'; ?>
            </div>
        </div>
    </div>
</div>